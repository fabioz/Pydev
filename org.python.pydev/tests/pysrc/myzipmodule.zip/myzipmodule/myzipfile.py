class MyZipClass(object):
    def myZipMethod(self):
        pass